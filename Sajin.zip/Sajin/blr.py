#!/usr/bin/env python
from __future__ import print_function, division
import numpy as np
import utils
from utils import opt
import tensorflow as tf
from keras import backend as K
config = tf.compat.v1.ConfigProto(intra_op_parallelism_threads=1, inter_op_parallelism_threads=1, \
                        allow_soft_placement=True, device_count = {'CPU': 1})
session = tf.compat.v1.Session(config=config)
K.set_session(session)

class BayesianLinearRegression:
    def __init__(self, last_layer, n_actions):
        self.last_layer = last_layer
        self.n_actions = n_actions
        
        self.eye = np.zeros((self.last_layer, self.last_layer))
        for i in range(self.last_layer):
            self.eye[i,i] = 1
        
        self.E_W = np.random.normal(loc=0, scale=.01, size=(self.n_actions, self.last_layer))
        self.E_W_target = np.random.normal(loc=0, scale=.01, size=(self.last_layer, self.last_layer))
        self.E_W_ = np.random.normal(loc=0, scale=.01, size=(self.n_actions, self.last_layer))
        self.Cov_W = np.random.normal(loc=0, scale= 1, size=(self.n_actions, self.last_layer, self.last_layer)) + self.eye
        self.Cov_W_decom = self.Cov_W
        for i in range(self.n_actions):
            self.Cov_W[i] = self.eye
            self.Cov_W_decom[i] = np.array(np.linalg.cholesky((self.Cov_W[i] + np.transpose(self.Cov_W[i]))/2.))
        self.Cov_W_target = self.Cov_W
        self.phiphiT = np.zeros((self.n_actions, self.last_layer, self.last_layer))
        self.phiY = np.zeros((self.n_actions, self.last_layer))
        
    def update_bayes_reg_phi(self, action, p0_mat, expected_q):
        self.phiphiT[action] += np.dot(p0_mat.T, p0_mat)
        self.phiY[action] += np.dot(p0_mat.T[action] , expected_q)
        
    def update_bayes_reg_weights(self):
        for i in range(self.n_actions):
            inv = np.linalg.inv(self.phiphiT[i] / utils.opt.sigma_n + 1 / utils.opt.sigma * self.eye)
            self.E_W[i] = np.array(np.dot(inv, self.phiY[i]) / utils.opt.sigma_n)
            self.Cov_W[i] = utils.opt.sigma * inv
            self.Cov_W_decom[i] = np.array(np.linalg.cholesky((self.Cov_W[i] + np.transpose(self.Cov_W[i]))/2.))

    def sample_W(self):
        '''
        Thompson sampling: sample a model W form the posterior distribution.
        '''
        for i in range(self.n_actions):
            sam = np.random.normal(loc=0, scale=1, size=(self.last_layer,1))
            self.E_W_[i] = self.E_W[i] + np.dot(self.Cov_W_decom[i], sam)[:,0]
        