#!/usr/bin/env python
from __future__ import print_function, division 

import os 
import sys
from random import sample
from collections import namedtuple
import numpy as np

import tensorflow as tf
from keras import backend as K
config = tf.compat.v1.ConfigProto(intra_op_parallelism_threads=1, inter_op_parallelism_threads=1, \
                        allow_soft_placement=True, device_count = {'CPU': 1})
session = tf.compat.v1.Session(config=config)
K.set_session(session)


Transition = namedtuple('Transition',('state', 'action', 'reward', 'next_state', 'done'))
class ReplayBuffer():
    """
    This class manages the replay buffer of each agent.
    """
    def __init__(self, replay_buffer_size):
        self.replay_buffer_size = replay_buffer_size
        self.memory = []
        self.position = 0
    def push(self, *args):
        if len(self.memory) < self.replay_buffer_size:
            self.memory.append(None)
        self.memory[self.position] = Transition(*args)
        self.position = (self.position + 1) % self.replay_buffer_size
    def sample(self, batch_size):
        return sample(self.memory, batch_size)
        
rewards=dict(
        # Penalty for each day that has passed.
        # Encourages agents to develop new policies, w.r.t which they will
        # win faster.
        day=0,
        # Penalty for death
        death=-5,
        # Reward for a victory
        victory=+25,
        # Penalty for losing
        lost=-25,
        # Reward (Penalty) for votes that are (not) eventually chosen during execution/kill.
        # Encourages a cooperative behaviour between agents.
        executed=1,
        trg_preferneces=-1,
        divine_wolf=15,
        divine_possessed=10,
        divine_human=2
    )

def vote_werewolf_15(agent, p0_mat, base_info, vote_15):
    p = -1
    idx = 1
    for i in range(1, 16):
        p0 = p0_mat[i-1, 1]
        if str(i) in base_info['roleMap'].keys():
            p0 *= 0.5
        if base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
            p = p0 * (1.0 + vote_15[:, i-1].sum()*1.0)
            idx = i
    return idx
    
def vote_possessed_15(agent, p0_mat, base_info, vote_15):
    p = -1
    idx = 1
    for i in range(1, 16):
        p0 = p0_mat[i-1, 1]
        if base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
            p = p0 * (1.0 + vote_15[:, i-1].sum()*1.0)
            idx = i
    return idx
    
def vote_human_15(agent, p0_mat, base_info, vote_15):
    p = -1
    idx = 1
    for i in range(1, 16):
        p0 = p0_mat[i-1, 1]
        if base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
            p = p0 * (1.0 + vote_15[:, i-1].sum()*0.5)
            idx = i
    return idx

def vote_werewolf_5(agent, p0_mat, base_info, vote_5):
    p = -1
    idx = 1
    for i in range(1, 6):
        p0 = p0_mat[i-1, 3]
        if base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
            p = p0 * (1.0 + vote_5[:, i-1].sum()*1.0)
            idx = i
    return idx
        
def vote_possessed_5(agent, p0_mat, base_info, vote_5):
    p = -1
    idx = 1
    for i in range(1, 6):
        p0 = p0_mat[i-1, 3]
        if base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
            p = p0 * (1.0 + vote_5[:, i-1].sum()*1.0)
            idx = i
    return idx

def vote_seer_5(agent, p0_mat, base_info, vote_5):
    p = -1
    idx = 1
    for i in range(1, 6):
        p0 = p0_mat[i-1, 1]
        if base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
            p = p0 * (1.0 + vote_5[:, i-1].sum()*0.5)
            idx = i
    return idx
   
def vote_human_5(agent, p0_mat, base_info, vote_5):
    p = -1
    idx = 1
    for i in range(1, 6):
        p0 = p0_mat[i-1, 1]
        if base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
            p = p0 * (1.0 + vote_5[:, i-1].sum()*0.5)
            idx = i
    return idx

def divine_15(agent, p0_mat, base_info):
    p = -1
    idx = 1
    for i in range(1, 16):
        p0 = p0_mat[i-1, 1]
        if base_info['statusMap'][str(i)] == 'ALIVE' and i not in agent.divined_list and p0 > p:
            p = p0
            idx = i
            
    return idx
    
def divine_5(agent, p0_mat, base_info):
    p = -1
    idx = 1
    for i in range(1, 6):
        p0 = p0_mat[i-1, 1]
        if base_info['statusMap'][str(i)] == 'ALIVE' and i not in agent.divined_list and p0 > p:
            p = p0
            idx = i
            
    return idx
    
def attack_15(agent, p0_mat, base_info):
    p = -1
    idx = 1
    for i in range(1, 16):
        p0 = p0_mat[i-1, 0]
        if base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p and i not in base_info['roleMap'].keys():
            p = p0
            idx = i
            
    return idx
    
def attack_5(agent, p0_mat, base_info):
    p = -1
    idx = 1
    for i in range(1, 6):
        p0 = p0_mat[i-1, 2]
        if base_info['statusMap'][str(i)] == 'ALIVE' and p0 < p and i != base_info['agentIdx']:
            p = p0
            idx = i
            
    return idx

class Options:
    def __init__(self):
        #Articheture
        self.batch_size = 10 # The size of the batch to learn the Q-function
        self.epsilon_min = 0.1 # Minimum level of stochasticity of policy (epsilon)-greedy
        self.gamma = 0.99 # The discount factor
        self.replay_start_size = 50000 # Start to backpropagated through the network, learning starts
        self.gamma_t = 0.5
        
        # optimization hyperparameters
        self.max_episode =   200000000 #max number of episodes#
        # self.lr = 0.0025 # RMSprop learning rate
        # self.rho = 0.95 # RMSprop gamma1
        # self.rms_eps = 0.01 # RMSprop epsilon bias
        self.f_sampling = 10 # frequency sampling E_W_ (Thompson Sampling)
        self.target_batch_size = 5000 #target update sample batch
        self.target_W_update = 10
        self.sigma = 0.001 # W prior variance
        self.sigma_n = 1 # noise variacne
        
opt = Options()
