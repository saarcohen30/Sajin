#!/usr/bin/env python
from __future__ import print_function, division 

# this is main script

import aiwolfpy
import aiwolfpy.contentbuilder as cb
from win_counter import WinCounter

# sample 
import aiwolfpy.cash

import numpy as np

myname = 'cash'

class PythonPlayer(object):
    
    def __init__(self, agent_name):
        # myname
        self.myname = agent_name
        
        # predictor from sample
        # DataFrame -> P
        self.predicter_15 = aiwolfpy.cash.Predictor_15_Keras()
        self.predicter_5 = aiwolfpy.cash.StaticPredictor_5("/data/model_60_0820.npz")
        
        self.win_counter = WinCounter()
        # List of strong agents
        self.strong_agents = []
        
    def getName(self):
        return self.myname
        
    def initialize(self, base_info, diff_data, game_setting):
        # print(base_info)
        # print(diff_data)
        # base_info
        self.base_info = base_info
        # game_setting
        self.game_setting = game_setting
        
        # initialize
        if self.game_setting['playerNum'] == 15:
            self.predicter_15.initialize(base_info, game_setting)
        elif self.game_setting['playerNum'] == 5:   
            self.predicter_5.initialize(base_info, game_setting)
                
        ### EDIT FROM HERE ###     
        self.divined_list = []
        self.comingout = ''
        self.myresult = ''
        self.not_reported = False
        self.vote_declare = 0
        self.vote_15 = np.zeros((15, 15))
        self.vote_5 = np.zeros((5, 5))
        self.strong_agents = self.win_counter.initialize()
        # List of divined werewolves
        self.black_list = []
        # List of divined possessed agents
        self.pos_list = []
        # List of divined villager-aligned players, which include both
        # Mediums and Bodyguards as well
        self.vil_list = []
        
        # List of agents which came out as Seers
        self.seer_list = []
        # List of agents which came out as Mediums
        self.medium_list = []
        # List of agents which came out as Bodyguards
        self.bodyguard_list = []

        
    def update(self, base_info, diff_data, request):
        # print(base_info)
        # print(diff_data)
        # update base_info
        self.base_info = base_info
        
        # Documenting agents which came out as Seers, Mediums and Bodyguards.
        for i in range(diff_data.shape[0]):
            if "COMINGOUT" in diff_data['text'][i]:
                if "SEER" in diff_data['text'][i] and not int(diff_data['agent'][i]) in self.seer_list:
                    self.seer_list.append(int(diff_data['agent'][i]))
                if "MEDIUM" in diff_data['text'][i] and not int(diff_data['agent'][i]) in self.medium_list:
                    self.medium_list.append(int(diff_data['agent'][i]))
                if "BODYGUARD" in diff_data['text'][i] and not int(diff_data['agent'][i]) in self.bodyguard_list:
                    self.bodyguard_list.append(int(diff_data['agent'][i]))
        
        # result
        if request == 'DAILY_INITIALIZE':
            for i in range(diff_data.shape[0]):
                # IDENTIFY
                if diff_data['type'][i] == 'identify':
                    self.not_reported = True
                    self.myresult = diff_data['text'][i]
                    
                # DIVINE
                if diff_data['type'][i] == 'divine':
                    self.not_reported = True
                    self.myresult = diff_data['text'][i]
                    
                # GUARD
                if diff_data['type'][i] == 'guard':
                    self.myresult = diff_data['text'][i]
                
            # POSSESSED
            if self.base_info['myRole'] == 'POSSESSED':
                self.not_reported = True
                
        # UPDATE
        if self.game_setting['playerNum'] == 15:
            # update pred
            self.predicter_15.update(diff_data)
        else:
            self.predicter_5.update(diff_data)
            
        # FINISH
        if request == 'FINISH':
            self.is_done = True
            if self.win_counter.is_finish == True:
                return None
            self.win_counter.is_finish = True
            is_werewolf_win = self.win_counter.finish(base_info, diff_data)
            
        # Updating the Seers' black lists
        if base_info['myRole'] == 'SEER':
            # Note that the update is performed solely for Seer agents.
            # Obviously, agents which were divined as Werewolves are 
            # inserted into the black list.
            for i in range(diff_data.shape[0]):
                if diff_data['type'][i] == 'divine':
                    role = diff_data['text'][i].split()[2] 
                    if role == 'WEREWOLF':
                        black_agent = diff_data['text'][i].split()[1]
                        black_agent_idx = int(black_agent.replace('Agent[','').replace(']',''))
                        self.black_list.append(black_agent_idx)
                
                    elif role == 'POSSESSED':
                        pos_agent = diff_data['text'][i].split()[1]
                        pos_agent_idx = int(pos_agent.replace('Agent[','').replace(']',''))
                        self.pos_list.append(pos_agent_idx)
                    
                    elif role == 'VILLAGER' or role == 'MEDIUM' or role == 'BODYGUARD':
                        vil_agent = diff_data['text'][i].split()[1]
                        vil_agent_idx = int(vil_agent.replace('Agent[','').replace(']',''))
                        self.vil_list.append(vil_agent_idx)

        
        
    def dayStart(self):
        self.vote_declare = 0
        self.talk_turn = 0
        self.whis_declare = 0
        return None
    
    def talk(self):        
        if self.game_setting['playerNum'] == 15:
            
            self.talk_turn += 1
            
            # 1.comingout anyway
            if self.base_info['myRole'] == 'SEER' and self.comingout == '':
                self.comingout = 'SEER'
                return cb.comingout(self.base_info['agentIdx'], self.comingout)
            elif self.base_info['myRole'] == 'MEDIUM' and self.comingout == '':
                self.comingout = 'MEDIUM'
                return cb.comingout(self.base_info['agentIdx'], self.comingout)
            elif self.base_info['myRole'] == 'POSSESSED' and self.comingout == '':
                self.comingout = 'SEER'
                return cb.comingout(self.base_info['agentIdx'], self.comingout)
            
            # 2.report
            if self.base_info['myRole'] == 'SEER' and self.not_reported:
                self.not_reported = False
                return self.myresult
            elif self.base_info['myRole'] == 'MEDIUM' and self.not_reported:
                self.not_reported = False
                return self.myresult
            elif self.base_info['myRole'] == 'POSSESSED' and self.not_reported:
                self.not_reported = False
                # FAKE DIVINE
                # highest prob ww in alive agents
                p = -1
                idx = 1
                p0_mat = self.predicter_15.ret_pred_wx(2)
                for i in range(1, 16):
                    p0 = p0_mat[i-1, 1]
                    if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                        p = p0
                        idx = i
                self.myresult = 'DIVINED Agent[' + "{0:02d}".format(idx) + '] ' + 'HUMAN'
                return self.myresult
                
            # 3.declare vote if not yet
            if self.vote_declare != self.vote():
                self.vote_declare = self.vote()
                return cb.vote(self.vote_declare)
                
            # 4. skip
            if self.talk_turn <= 10:
                return cb.skip()
                
            return cb.over()
        else:
            self.talk_turn += 1
            
            # 1.comingout anyway
            if self.base_info['myRole'] == 'SEER' and self.comingout == '':
                self.comingout = 'SEER'
                return cb.comingout(self.base_info['agentIdx'], self.comingout)
            elif self.base_info['myRole'] == 'MEDIUM' and self.comingout == '':
                self.comingout = 'MEDIUM'
                return cb.comingout(self.base_info['agentIdx'], self.comingout)
            elif self.base_info['myRole'] == 'POSSESSED' and self.comingout == '':
                self.comingout = 'SEER'
                return cb.comingout(self.base_info['agentIdx'], self.comingout)
            
            # 2.report
            if self.base_info['myRole'] == 'SEER' and self.not_reported:
                self.not_reported = False
                return self.myresult
            elif self.base_info['myRole'] == 'MEDIUM' and self.not_reported:
                self.not_reported = False
                return self.myresult
            elif self.base_info['myRole'] == 'POSSESSED' and self.not_reported:
                self.not_reported = False
                # FAKE DIVINE
                # highest prob ww in alive agents
                p = -1
                idx = 1
                p0_mat = self.predicter_5.ret_pred_wx(2)
                for i in range(1, 6):
                    p0 = p0_mat[i-1, 1]
                    if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                        p = p0
                        idx = i
                self.myresult = 'DIVINED Agent[' + "{0:02d}".format(idx) + '] ' + 'HUMAN'
                return self.myresult
                
            # 3.declare vote if not yet
            if self.vote_declare != self.vote():
                self.vote_declare = self.vote()
                return cb.vote(self.vote_declare)
                
            # 4. skip
            if self.talk_turn <= 10:
                return cb.skip()
                
            return cb.over()
    
    def whisper(self):
        if self.whis_declare == 0:
            self.whis_declare += 1
            return cb.comingout(self.base_info['agentIdx'], 'VILLAGER')
        else:
            return cb.skip()
        
    def vote(self):
        
        d = self.base_info["day"] - 1
        if d > 9:
            d = 9
            
        if self.game_setting['playerNum'] == 15:
            # count vote
            self.vote_15 = self.predicter_15.x_3d_tstm[:, :, d, 8]
            for i in range(1, 16):
                # do not vote to dead
                if self.base_info['statusMap'][str(i)] == 'DEAD':
                    self.vote_15[i-1, :] = 0
            # do not vote myself
            self.vote_15[self.base_info['agentIdx']-1, :] = 0
            
            p0_mat = self.predicter_15.ret_pred_wx(0)
            idx = 1
            if self.base_info['myRole'] == "WEREWOLF":
                p = -1
                idx = 1
                for i in range(1, 16):
                    p0 = p0_mat[i-1, 1]
                    if str(i) in self.base_info['roleMap'].keys():
                        p0 *= 0.5
                    if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                        p = p0
                        idx = i
            elif self.base_info['myRole'] == "POSSESSED":
                p = -1
                idx = 1
                for i in range(1, 16):
                    p0 = p0_mat[i-1, 1]
                    if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                        p = p0
                        idx = i
            elif self.base_info['myRole'] == "SEER":
                if len(self.black_list) != 0:
                    # If a Werewolf was successfully divined by a Seer,
                    # he should be voted.
                    idx = 1
                    for i in range(1, 16):
                        if self.base_info['statusMap'][str(i)] == 'ALIVE' and i in self.black_list:
                            idx = i
                            break
                        break
                elif len(self.pos_list) != 0:
                    # If a Possessed agent was successfully divined by a Seer,
                    # he should be voted.
                    idx = 1
                    for i in range(1, 16):
                        if self.base_info['statusMap'][str(i)] == 'ALIVE' and i in self.pos_list:
                            idx = i
                            break
                        break
                else:
                    # idx = utils.vote_seer_5(self, p0_mat)
                    p = -1
                    idx = 1
                    for i in range(1, 16):
                        p0 = p0_mat[i-1, 1]
                        if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p and not (i in self.vil_list):
                            p = p0 * (1.0 + self.vote_15[:, i-1].sum()*0.5)
                            idx = i
            else:
                if self.base_info['day'] < 4:
                    if len(self.seer_list) > 2:
                        p = -1
                        idx = 1
                        for i in self.seer_list:
                            if self.base_info['statusMap'][str(i)] == 'ALIVE' and i != self.base_info['agentIdx']:
                                p0 = p0_mat[i-1, 1]
                                if p0 > p:
                                    p = p0 * (1.0 + self.vote_15[:, i-1].sum()*0.5)
                                    idx = i
                    elif len(self.medium_list) > 2:
                        p = -1
                        idx = 1
                        for i in self.medium_list:
                            if self.base_info['statusMap'][str(i)] == 'ALIVE' and i != self.base_info['agentIdx']:
                                p0 = p0_mat[i-1, 1]
                                if p0 > p:
                                    p = p0 * (1.0 + self.vote_15[:, i-1].sum()*0.5)
                                    idx = i
                    elif len(self.bodyguard_list) > 2:
                        p = -1
                        idx = 1
                        for i in self.bodyguard_list:
                            if self.base_info['statusMap'][str(i)] == 'ALIVE' and i != self.base_info['agentIdx']:
                                p0 = p0_mat[i-1, 1]
                                if p0 > p:
                                    p = p0 * (1.0 + self.vote_15[:, i-1].sum()*0.5)
                                    idx = i
                else:
                    # highest prob ww in alive agents provided watashi ningen
                    p = -1
                    idx = 1
                    for i in range(1, 16):
                        p0 = p0_mat[i-1, 1]
                        if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                            p = p0 * (1.0 + self.vote_15[:, i-1].sum()*0.5)
                            idx = i
            return idx
        else:
            self.vote_5 = self.predicter_5.x_3d[:, :, 8]
            idx = 1
            if self.base_info['myRole'] == "WEREWOLF":
                p0_mat = self.predicter_5.ret_pred_wx(1)
                p = -1
                idx = 1
                for i in range(1, 6):
                    p0 = p0_mat[i-1, 3]
                    if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                        p = p0 * (1.0 + self.vote_5[:, i-1].sum()*1.0)
                        idx = i
            elif self.base_info['myRole'] == "POSSESSED":
                p0_mat = self.predicter_5.ret_pred_wx(2)
                p = -1
                idx = 1
                for i in range(1, 6):
                    p0 = p0_mat[i-1, 3]
                    if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                        p = p0 * (1.0 + self.vote_5[:, i-1].sum()*1.0)
                        idx = i
            elif self.base_info['myRole'] == "SEER":
                if len(self.black_list) != 0:
                    # If a Werewolf was successfully divined by a Seer,
                    # he should be voted.
                    idx = 1
                    for i in range(1, 6):
                        if self.base_info['statusMap'][str(i)] == 'ALIVE' and i in self.black_list:
                            idx = i
                            break
                        break
                elif len(self.pos_list) != 0:
                    # If a Possessed agent was successfully divined by a Seer,
                    # he should be voted.
                    idx = 1
                    for i in range(1, 6):
                        if self.base_info['statusMap'][str(i)] == 'ALIVE' and i in self.pos_list:
                            idx = i
                            break
                        break
                else:
                    p0_mat = self.predicter_5.ret_pred_wx(3)
                    p = -1
                    idx = 1
                    for i in range(1, 6):
                        p0 = p0_mat[i-1, 1]
                        if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p  and not (i in self.vil_list):
                            p = p0 * (1.0 + self.vote_5[:, i-1].sum()*0.5)
                            idx = i
            else:
                # If there are two Seers that came out - 
                # the agent shall vote for any agent other than itself.
                if len(self.seer_list) >= 2:
                    p = -1
                    idx = 1
                    for i in range(1, 6):
                        if self.base_info['statusMap'][str(i)] == 'ALIVE' and not (i in self.seer_list) and (i != self.base_info['agentIdx']):
                            p0 = p0_mat[i-1, 1]
                            if p0 > p:
                                p = p0 * (1.0 + self.vote_5[:, i-1].sum()*0.5)
                                idx = i
                        # else:
                        #     continue
                        # break
                else:
                    p0_mat = self.predicter_5.ret_pred_wx(0)
                    p = -1
                    idx = 1
                    for i in range(1, 6):
                        p0 = p0_mat[i-1, 1]
                        if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                            p = p0 * (1.0 + self.vote_5[:, i-1].sum()*0.5)
                            idx = i
            return idx
    
    def attack(self):
        if self.game_setting['playerNum'] == 15:
            # highest prob hm in alive agents
            p = -1
            idx = 1
            p0_mat = self.predicter_15.ret_pred_wx(1)
            for i in range(1, 16):
                p0 = p0_mat[i-1, 0]
                if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p and i not in self.base_info['roleMap'].keys():
                    p = p0
                    idx = i
            return idx
        else:
            self_id = self.base_info['agentIdx']
            
            # If there is a single Seer CO, it will be attacked, 
            # and if there are two Seer COs, the agent will attack a strong 
            # villager other than a Seer.
            if self.base_info['day'] == 1 and ((len(self.seer_list) == 1 and int(self.seer_list[0]) == self_id) or len(self.seer_list) > 0) :
                if len(self.seer_list) == 1 and int(self.seer_list[0]) != self_id:
                    return int(self.seer_list[0])
            elif len(self.strong_agents) > 0:
                # Strong villagers shall be attacked
                p = 1
                idx = 1
                p0_mat = self.predicter_5.ret_pred_wx(1)
                for i in self.strong_agents:
                    p0 = p0_mat[int(i)-1, 2]
                    if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 < p and int(i) != self_id:
                        p = p0
                        idx = i
                return idx
            
            # lowest prob ps in alive agents
            p0_mat = self.predicter_5.ret_pred_wx(1)
            p = 1
            idx = 1
            for i in range(1, 6):
                p0 = p0_mat[i-1, 2]
                if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 < p and i != self.base_info['agentIdx']:
                    p = p0
                    idx = i
            return idx
    
    def divine(self):
        if self.game_setting['playerNum'] == 15:
            # highest prob ww in alive and not divined agents provided watashi ningen
            p = -1
            idx = 1
            p0_mat = self.predicter_15.ret_pred_wx(0)
            for i in range(1, 16):
                p0 = p0_mat[i-1, 1]
                if self.base_info['statusMap'][str(i)] == 'ALIVE' and i not in self.divined_list and p0 > p:
                    p = p0
                    idx = i
            self.divined_list.append(idx)
            return idx
        else:
            # highest prob ww in alive and not divined agents provided watashi ningen
            p = -1
            idx = 1
            p0_mat = self.predicter_5.ret_pred_wx(3)
            for i in range(1, 6):
                p0 = p0_mat[i-1, 1]
                if self.base_info['statusMap'][str(i)] == 'ALIVE' and i not in self.divined_list and p0 > p:
                    p = p0
                    idx = i
            self.divined_list.append(idx)
            return idx
    
    def guard(self):
        if self.game_setting['playerNum'] == 15:
            # highest prob hm in alive agents
            p = -1
            idx = 1
            p0_mat = self.predicter_15.ret_pred_wx(0)
            for i in range(1, 16):
                p0 = p0_mat[i-1, 0]
                if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                    p = p0
                    idx = i
            return idx
        else:
            # no need
            return 1
    
    def finish(self):
        self.win_counter.finish_term(100)
        pass
        

agent = PythonPlayer(myname)

# run
if __name__ == '__main__':
    aiwolfpy.connect(agent)
    