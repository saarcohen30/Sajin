#!/usr/bin/env python
from __future__ import print_function, division 


import aiwolfpy
import aiwolfpy.contentbuilder as cb
import logging, json
import os

import aiwolfpy.cash
import utils
from utils import opt
import numpy as np
from blr import BayesianLinearRegression

import tensorflow as tf
from keras import backend as K
config = tf.compat.v1.ConfigProto(intra_op_parallelism_threads=1, inter_op_parallelism_threads=1, \
                        allow_soft_placement=True, device_count = {'CPU': 1})
session = tf.compat.v1.Session(config=config)
K.set_session(session)
from keras.optimizers import RMSprop


myname = 'PretrainedSajin'

def game_initializer(df, agent=1):
    # role
    role = "VILLAGER"
    df_list = df["text"][agent - 1].split()
    if len(df_list) > 3 and agent > 0:
        role = df_list[2]
    
    # filter by role
    if role in ["VILLAGER", "POSSESSED"]:
        df = df[df["type"].isin(["talk", "vote", "execute", "dead", "status"])]
    elif role == "MEDIUM":
        df = df[df["type"].isin(["talk", "vote", "execute", "dead", "identify", "status"])]
    elif role == "SEER":
        df = df[df["type"].isin(["talk", "vote", "execute", "dead", "divine", "status"])]
    elif role == "BODYGUARD":
        df = df[df["type"].isin(["talk", "vote", "execute", "dead", "guard", "status"])]
    elif role == "WEREWOLF":
        df = df[df["type"].isin(["talk", "vote", "execute", "dead", "whisper", "attack", "attack_vote"])]
        
    return role, df

def game_data_filter(df, day, predictor, phase='daily_initialize', agent=1):
    # filter by time
    if phase == 'daily_initialize':
        df = df[df["day"] < day]
    else:
        df = df[(df["day"] < day) | ((df["day"] == day) & (df["type"] == 'talk'))]
    
    predictor.update(df.reset_index())

def vote_werewolf_15(agent, p0_mat, diff_data, roleMap, vote_15):
    p = -1
    idx = 1
    for i in range(1, 16):
        p0 = p0_mat[i-1, 1]
        if str(i) in roleMap:
            p0 *= 0.5
        if agent.get_status(diff_data, i) == 'ALIVE' and p0 > p:
            p = p0 * (1.0 + vote_15[:, i-1].sum()*1.0)
            idx = i
    return idx
    
def vote_possessed_15(agent, p0_mat, diff_data, vote_15):
    p = -1
    idx = 1
    for i in range(1, 16):
        p0 = p0_mat[i-1, 1]
        if get_status(diff_data, i) == 'ALIVE' and p0 > p:
            p = p0 * (1.0 + vote_15[:, i-1].sum()*1.0)
            idx = i
    return idx
    
def vote_human_15(agent, p0_mat, diff_data, vote_15):
    p = -1
    idx = 1
    for i in range(1, 16):
        p0 = p0_mat[i-1, 1]
        if get_status(diff_data, i) == 'ALIVE' and p0 > p:
            p = p0 * (1.0 + vote_15[:, i-1].sum()*0.5)
            idx = i
    return idx

def vote_werewolf_5(agent, p0_mat, diff_data, vote_5):
    p = -1
    idx = 1
    for i in range(1, 6):
        p0 = p0_mat[i-1, 3]
        if get_status(diff_data, i) == 'ALIVE' and p0 > p:
            p = p0 * (1.0 + vote_5[:, i-1].sum()*1.0)
            idx = i
    return idx
        
def vote_possessed_5(agent, p0_mat, diff_data, vote_5):
    p = -1
    idx = 1
    for i in range(1, 6):
        p0 = p0_mat[i-1, 3]
        if get_status(diff_data, i) == 'ALIVE' and p0 > p:
            p = p0 * (1.0 + vote_5[:, i-1].sum()*1.0)
            idx = i
    return idx

def vote_seer_5(agent, p0_mat, diff_data, vote_5):
    p = -1
    idx = 1
    for i in range(1, 6):
        p0 = p0_mat[i-1, 1]
        if get_status(diff_data, i) == 'ALIVE' and p0 > p:
            p = p0 * (1.0 + vote_5[:, i-1].sum()*0.5)
            idx = i
    return idx
   
def vote_human_5(agent, p0_mat, diff_data, vote_5):
    p = -1
    idx = 1
    for i in range(1, 6):
        p0 = p0_mat[i-1, 1]
        if get_status(diff_data, i) == 'ALIVE' and p0 > p:
            p = p0 * (1.0 + vote_5[:, i-1].sum()*0.5)
            idx = i
    return idx

def divine_15(agent, p0_mat, diff_data):
    p = -1
    idx = 1
    for i in range(1, 16):
        p0 = p0_mat[i-1, 1]
        if get_status(diff_data, i) == 'ALIVE' and i not in agent.divined_list and p0 > p:
            p = p0
            idx = i
            
    return idx
    
def divine_5(agent, p0_mat, diff_data):
    p = -1
    idx = 1
    for i in range(1, 6):
        p0 = p0_mat[i-1, 1]
        if get_status(diff_data, i) == 'ALIVE' and i not in agent.divined_list and p0 > p:
            p = p0
            idx = i
            
    return idx
    
def attack_15(agent, p0_mat, diff_data, roleMap):
    p = -1
    idx = 1
    for i in range(1, 16):
        p0 = p0_mat[i-1, 0]
        if get_status(diff_data, i) == 'ALIVE' and p0 > p and i not in roleMap:
            p = p0
            idx = i
            
    return idx
    
def attack_5(agent, p0_mat, diff_data):
    p = -1
    idx = 1
    for i in range(1, 6):
        p0 = p0_mat[i-1, 2]
        if get_status(diff_data, i) == 'ALIVE' and p0 < p and i != agent.myidx:
            p = p0
            idx = i
            
    return idx
    
def get_status(diff_data, idx):
    status = diff_data[(diff_data["type"] == "status") & (diff_data["agent"] == idx)].reset_index()
    return status["text"][0]

def update_double_q_network(agent, n_agents):
    '''
    Update procedure for the case in which the SBDQN is randomly chosen  
    w.r.t a specific random choice under the stochastic settings of the SBDQN.
    '''
    minibatch = agent.replay_buffer.sample(opt.batch_size)
    
    if n_agents == 15:
        for batch in minibatch:
            x3d, x2d, df, roleMap, vote_15 = batch.state
            next_x3d, next_x2d, next_df, next_roleMap, next_vote_15 = batch.next_state
            with tf.GradientTape() as tape:  
                p0_mat = tf.tensordot(agent.predicter_15.pred_5460(next_x3d, next_x2d, wn=True).T, tf.cast(agent.BLR.E_W_, tf.float32), axes = [0, 0])
                idx = 1
                action = 1
                
                # DIVINE
                if batch.action[0] == 'divine':
                    idx = divine_15(agent, p0_mat, next_df)
                    
                # VOTE
                if batch.action[0] == 'vote':
                    if agent.role == "WEREWOLF":
                        idx = vote_werewolf_15(agent, p0_mat, next_df, next_roleMap, next_vote_15)
                    elif agent.role == "POSSESSED":
                        idx = vote_possessed_15(agent, p0_mat, next_df, next_vote_15)
                    else:
                        idx = vote_human_15(agent, p0_mat, next_df, next_vote_15)
                    
                p0_mat_target = tf.tensordot(agent.predicter_15.target_pred_5460(next_x3d, next_x2d, wn=True).T, tf.cast(agent.BLR.E_W_target, tf.float32), axes = [0, 0])
                online_q = tf.tensordot(agent.predicter_15.pred_5460(x3d, x2d, wn=True).T, tf.cast(agent.BLR.E_W, tf.float32), axes = [0, 0])
                    
                # ATTACK
                if batch.action[0] == 'attack_vote':
                    action = 0
                    p0_mat = tf.tensordot(agent.predicter_15.pred_5460(next_x3d, next_x2d).T, tf.cast(agent.BLR.E_W_, tf.float32), axes = [0, 0])
                    idx = attack_15(agent, p0_mat, next_df, next_roleMap)
                    p0_mat_target = tf.tensordot(agent.predicter_15.target_pred_5460(next_x3d, next_x2d).T, tf.cast(agent.BLR.E_W_target, tf.float32), axes = [0, 0])
                    online_q = tf.tensordot(agent.predicter_15.pred_5460(x3d, x2d).T, tf.cast(agent.BLR.E_W, tf.float32), axes = [0, 0])
                    
                ddqn_q = tf.reduce_sum(p0_mat_target * tf.one_hot(idx-1, 45, 1.0, 0.0).reshape(15,3), axis=1)
                expected_q = batch.reward + opt.gamma * ddqn_q * (1.0 - tf.cast(batch.done, tf.float32))
                
                main_q = tf.reduce_sum(online_q * tf.one_hot(batch.action[1]-1, 45, 1.0, 0.0).reshape(15,3), axis=1)
                l = agent.loss(tf.stop_gradient(expected_q), main_q)
                agent.BLR.update_bayes_reg_phi(action, p0_mat, expected_q)
                agent.is_updated_phi = True
                    
            gradients_application(agent, tape, agent.predicter_15.dqn.trainable_variables, l, main_q)   
    else:
        for batch in minibatch:
            with tf.GradientTape() as tape:
                action = 1
                next_x = concatenated_state(batch.next_state[0:2])
                x = concatenated_state(batch.state[0:2])
                df, roleMap, vote_5 = batch.next_state[2:5]
                idx = 1
                
                # if batch.done:
                #     expected_q = batch.reward
                # else:
                r = 3
                next_p0_mat, p0_mat_target = get_p0_mats_5(agent, next_x, r)
                # DIVINE
                if batch.action[0] == 'divine':
                    idx = divine_5(agent, next_p0_mat, df)
                    
                # VOTE
                if batch.action[0] == 'vote':
                    if agent.role == "WEREWOLF":
                        r = 1
                        action = 3
                        next_p0_mat, p0_mat_target = get_p0_mats_5(agent, next_x, r)
                        idx = vote_werewolf_5(agent, next_p0_mat, df, vote_5)
                    elif agent.role == "POSSESSED":
                        r = 2
                        action = 3
                        next_p0_mat, p0_mat_target = get_p0_mats_5(agent, next_x, r)
                        idx = vote_possessed_5(agent, next_p0_mat, df, vote_5)
                    else:
                        if agent.role == "SEER":
                            idx = vote_seer_5(agent, next_p0_mat, df, vote_5)
                        else:
                            r = 0
                            next_p0_mat, p0_mat_target = get_p0_mats_5(agent, next_x, r)
                            idx = vote_human_5(agent, next_p0_mat, df, vote_5)
                            
                # ATTACK
                if batch.action[0] == 'attack_vote':
                    r = 1
                    action = 2
                    next_p0_mat, p0_mat_target = get_p0_mats_5(agent, next_x, r)
                    idx = attack_5(agent, next_p0_mat, df)
                    
                ddqn_q = tf.reduce_sum(p0_mat_target * tf.one_hot(idx-1, 20, 1.0, 0.0).reshape(5,4), axis=1)
                expected_q = batch.reward + opt.gamma * ddqn_q * (1.0 - tf.cast(batch.done, tf.float32))
                
                if batch.done:
                    r = 0
                    
                p0_mat = agent.predicter_5.ret_pred_wx(x, r, training=True)
                main_q = tf.reduce_sum(p0_mat * tf.one_hot(batch.action[1]-1, 20, 1.0, 0.0).reshape(5,4), axis=1)
                l = agent.loss(tf.stop_gradient(expected_q), main_q)
                agent.BLR.update_bayes_reg_phi(action, p0_mat, expected_q)
                agent.is_updated_phi = True
                
            gradients_application(agent, tape, agent.predicter_5.dqn.trainable_variables, l, main_q)

def update_q_network(agent, n_agents):
    minibatch = agent.replay_buffer.sample(opt.batch_size)
    
    if n_agents == 15:
        for batch in minibatch:
            x3d, x2d, df, roleMap, vote_15 = batch.state
            next_x3d, next_x2d, next_df, next_roleMap, next_vote_15 = batch.next_state
            with tf.GradientTape() as tape:
                action = 1
                p0_mat_target = tf.tensordot(agent.predicter_15.target_pred_5460(next_x3d, next_x2d, wn=True).T, tf.cast(agent.BLR.E_W_target, tf.float32), axes = [0, 0])
                idx = 1
                
                # DIVINE
                if batch.action[0] == 'divine':
                    idx = divine_15(agent, p0_mat_target, next_df)
                    
                # VOTE
                if batch.action[0] == 'vote':
                    if agent.role == "WEREWOLF":
                        idx = vote_werewolf_15(agent, p0_mat_target, next_df, next_roleMap, vote_15)
                    elif agent.role == "POSSESSED":
                        idx = vote_possessed_15(agent, p0_mat_target, next_df, next_vote_15)
                    else:
                        idx = vote_human_15(agent, p0_mat_target, next_df, next_vote_15)
                    
                online_q = tf.tensordot(agent.predicter_15.pred_5460(x3d, x2d, wn=True).T, tf.cast(agent.BLR.E_W, tf.float32), axes = [0, 0])
                    
                # ATTACK
                if batch.action[0] == 'attack_vote':
                    action = 0
                    p0_mat_target = tf.tensordot(agent.predicter_15.ret_target_pred(next_x3d, next_x2d).T, tf.cast(agent.BLR.E_W_target, tf.float32), axes = [0, 0])
                    idx = attack_15(agent, p0_mat_target, next_df, next_roleMap)
                    online_q = tf.tensordot(agent.predicter_15.pred_5460(x3d, x2d).T, tf.cast(agent.BLR.E_W, tf.float32), axes = [0, 0])
                    
                ddqn_q = tf.reduce_sum(p0_mat_target * tf.one_hot(idx-1, 45, 1.0, 0.0).reshape(15,3), axis=1)
                expected_q = batch.reward + opt.gamma * ddqn_q * (1.0 - tf.cast(batch.done, tf.float32))
                
                main_q = tf.reduce_sum(online_q * tf.one_hot(batch.action[1]-1, 45, 1.0, 0.0).reshape(15,3), axis=1)
                l = agent.loss(tf.stop_gradient(expected_q), main_q)
                agent.BLR.update_bayes_reg_phi(action, p0_mat_target, expected_q)
                agent.is_updated_phi = True
                    
            gradients_application(agent, tape, agent.predicter_15.dqn.trainable_variables, l, main_q)   
    else:
        for batch in minibatch:
            with tf.GradientTape() as tape:
                action = 1
                next_x = concatenated_state(batch.next_state[0:2])
                x = concatenated_state(batch.state[0:2])
                df, roleMap, vote_5 = batch.next_state[2:5]
                idx = 1

                r = 3
                _, p0_mat_target = get_p0_mats_5(agent, next_x, r)
                # DIVINE
                if batch.action[0] == 'divine':
                    idx = divine_5(agent, p0_mat_target, df)
                    
                # VOTE
                if batch.action[0] == 'vote':
                    if agent.role == "WEREWOLF":
                        r = 1
                        action = 3
                        _, p0_mat_target = get_p0_mats_5(agent, next_x, r)
                        idx = vote_werewolf_5(agent, p0_mat_target, df, vote_5)
                    elif agent.role == "POSSESSED":
                        r = 2
                        action = 3
                        _, p0_mat_target = get_p0_mats_5(agent, next_x, r)
                        idx = vote_possessed_5(agent, p0_mat_target, df, vote_5)
                    else:
                        if agent.role == "SEER":
                            idx = vote_seer_5(agent, p0_mat_target, df, vote_5)
                        else:
                            r = 0
                            _, p0_mat_target = get_p0_mats_5(agent, next_x, r)
                            idx = vote_human_5(agent, p0_mat_target, df, vote_5)
                            
                # ATTACK
                if batch.action[0] == 'attack_vote':
                    r = 1
                    action = 2
                    _, p0_mat_target = get_p0_mats_5(agent, next_x, r)
                    idx = attack_5(agent, p0_mat_target, df)
                    
                ddqn_q = tf.reduce_sum(p0_mat_target * tf.one_hot(idx-1, 20, 1.0, 0.0).reshape(5,4), axis=1)
                expected_q = batch.reward + opt.gamma * ddqn_q * (1.0 - tf.cast(batch.done, tf.float32))
                
                if batch.done:
                    r = 0
                    
                p0_mat = agent.predicter_5.ret_pred_wx(x, r, training=True)
                main_q = tf.reduce_sum(p0_mat * tf.one_hot(batch.action[1]-1, 20, 1.0, 0.0).reshape(5,4), axis=1)
                l = agent.loss(tf.stop_gradient(expected_q), main_q)
                agent.BLR.update_bayes_reg_phi(action, p0_mat_target, expected_q)
                agent.is_updated_phi = True
                
            gradients_application(agent, tape, agent.predicter_5.dqn.trainable_variables, l, main_q)

def concatenated_state(state):
    x3d, x2d = state
    x = np.concatenate([x3d.reshape((1, 5*5*12)), x2d.reshape((1, 5*8))], axis=1)
    return x.reshape((1,) + x.shape)
    
def get_p0_mats_5(agent, next_x, r):
    return agent.predicter_5.ret_pred_wx(next_x, r), agent.predicter_5.ret_target_pred_wx(next_x, r)
    
def gradients_application(agent, tape, trainable_variables, l, main_q):
    gradients = tape.gradient(l, trainable_variables)
    clipped_gradients = [tf.clip_by_norm(grad, 10) for grad in gradients]
    agent.optimizer.apply_gradients(zip(gradients, trainable_variables))
            
    agent.loss_metric.update_state(l)
    agent.q_metric.update_state(main_q)
    
class PretrainedSajinPlayer(object):
    total_num_days = 0
    def __init__(self):
        # myname        
        # predictor from sample
        # DataFrame -> P
        self.myidx = 1
        
        self.predicter_15 = aiwolfpy.cash.Predictor_15()
        self.predicter_5 = aiwolfpy.cash.Predictor_5()

        self.replay_buffer = utils.ReplayBuffer(replay_buffer_size=10000)
        self.optimizer = RMSprop(learning_rate=0.0025, rho=0.95, epsilon=0.01)
        self.loss = tf.keras.losses.MSE
        self.loss_metric = tf.keras.metrics.Mean(name="loss")
        self.q_metric = tf.keras.metrics.Mean(name="Q_value")
        
    def getIDX(self):
        return self.myidx
    
    def initialize(self, diff_data, n_agents):
        # initialize
        self.role, self.df = game_initializer(diff_data, agent=self.myidx)
        
        self.is_updated_phi = False
        if n_agents == 15:
            self.predicter_15.initialize({"agentIdx":self.myidx, "roleMap":{str(self.myidx):self.role}}, {})
            self.BLR = BayesianLinearRegression(3, 3)
        else:
            self.predicter_5.initialize({"agentIdx":self.myidx, "roleMap":{str(self.myidx):self.role}}, {})
            self.BLR = BayesianLinearRegression(4, 4)
                
        ### EDIT FROM HERE ###     
        self.reward = 0
        self.is_done = False
        self.executed = -1
        self.attacked = -1
        self.myresult = ''
        
    def update(self, request, day, roleMap, is_werewolf_win, n_agents):
        self.total_num_days += 1
        
        # UPDATE
        diff_data = self.df[self.df["day"] == day]
        if n_agents == 15:
            state = [self.predicter_15.x_3d, self.predicter_15.x_2d, diff_data, roleMap[day] if day >= 2 else {}, self.predicter_15.x_3d[:, :, 8]]
            game_data_filter(self.df, day, predictor=self.predicter_15, phase=request, agent=self.myidx)
            next_state = [self.predicter_15.x_3d, self.predicter_15.x_2d, self.df[self.df["day"] == day+1], roleMap[day+1] if day+1 >= 2 else {}, self.predicter_15.x_3d[:, :, 8]]
        else:
            state = [self.predicter_5.x_3d, self.predicter_5.x_2d, diff_data, roleMap[day] if day >= 2 else {}, self.predicter_5.x_3d[:, :, 8]]
            game_data_filter(self.df, day, predictor=self.predicter_5, phase=request, agent=self.myidx)
            next_state = [self.predicter_5.x_3d, self.predicter_5.x_2d, self.df[self.df["day"] == day+1], roleMap[day+1] if day+1 >= 2 else {}, self.predicter_5.x_3d[:, :, 8]]
            
        # Penalizing a dead agent
        if get_status(diff_data, self.myidx) == 'DEAD':
            self.reward += utils.rewards.get("death")
        
        # result
        if request == 'DAILY_INITIALIZE':
            type_df = diff_data[diff_data["type"] != "status"].reset_index()
            for i in range(type_df.shape[0]):                   
                # DIVINE
                if type_df['type'][i] == 'divine':
                    self.myresult = type_df['text'][i]
                    
                    # utils.rewards for the divination performed by a Seer
                    if self.role == 'SEER':
                        divined_agent = int(type_df['agent'][i])
                        if self.myresult.split()[2] == 'WEREWOLF':
                            self.replay_buffer.push(state, ['divine', divined_agent, diff_data], utils.rewards.get("divine_wolf"), next_state, False)
                        elif self.myresult.split()[2] == 'POSSESSED':
                            self.replay_buffer.push(state, ['divine', divined_agent, diff_data], utils.rewards.get("divine_possessed"), next_state, False)
                        else:
                            self.replay_buffer.push(state, ['divine', divined_agent, diff_data], utils.rewards.get("divine_human"), next_state, False)

                # GUARD
                if type_df['type'][i] == 'guard':
                    self.myresult = df['text'][i]
                    
                # Retrieving the executed agent's ID
                if type_df['type'][i] == 'execute':
                    self.executed = int(type_df['agent'][i])
                    
                # VOTE
                if type_df['type'][i] == 'vote':
                    # agent = diff_data['text'][i].split()[1]
                    # agent_idx = int(agent.replace('Agent[','').replace(']',''))
                    agent_idx = int(type_df['agent'][i])
                    vote_reward = 0
                    if agent_idx == self.executed:
                        vote_reward = self.reward + utils.rewards.get("executed")
                    else:
                        vote_reward = self.reward + utils.rewards.get("trg_preferneces")
                        
                    self.replay_buffer.push(state, ['vote', agent_idx, diff_data], vote_reward, next_state, False)
                    
                # Retrieving the attacked agent's ID
                if type_df['type'][i] == 'attack':
                    self.attacked = int(type_df['agent'][i])
                    
                # ATTACK
                if type_df['type'][i] == 'attack_vote':
                    # agent = diff_data['text'][i].split()[1]
                    # agent_idx = int(agent.replace('Agent[','').replace(']',''))
                    agent_idx = int(type_df['agent'][i])
                    attack_reward = 0
                    if agent_idx == self.attacked:
                        attack_reward = self.reward + utils.rewards.get("executed")
                    else:
                        attack_reward = self.reward + utils.rewards.get("trg_preferneces")
                        
                    self.replay_buffer.push(state, ['attack_vote', agent_idx, diff_data], attack_reward, next_state, False)
        
        
        # FINISH
        if request == 'FINISH':
            self.is_done = True

            # Rewarding and penalizing for winning and losing (resp.).
            if is_werewolf_win:
                # The Werewolf team won
                if self.role == 'WEREWOLF' or self.role == 'POSSESSED':
                    self.reward += utils.rewards.get('victory')
                else:
                    self.reward += utils.rewards.get('lost')
            else:
                # The Villagers team won
                if self.role == 'WEREWOLF' or self.role == 'POSSESSED':
                    self.reward += utils.rewards.get('lost')
                else:
                    self.reward += utils.rewards.get('victory')
            
            # Recording the terminal experience in the replay buffer.
            # Note that the reward is solely required for the subsequent computation.
            self.replay_buffer.push(state, ['finish', self.myidx, diff_data], self.reward, next_state, True)
        
        self.reward = 0
        
        if self.replay_buffer.position > opt.batch_size:
            if tf.random.uniform((), minval=0, maxval=1, dtype=tf.float32) > opt.gamma_t:
                update_double_q_network(self, n_agents)
            else:
                update_q_network(self, n_agents)
        
        # Thompson Sampling
        if self.total_num_days % opt.f_sampling == 0 and self.is_updated_phi:
            # The execution of Thompson sampling appears to be computationally expensive in terms
            # of runtime when considering 15 players. We thus limit its utilization to 5 players.
            self.is_updated_phi = False
            self.BLR.update_bayes_reg_weights()
            self.BLR.sample_W()
            # print(self.predicter_5.dqn.watshi_xxx)
            # self.predicter_5.dqn.watshi_xxx = self.BLR.E_W_.T
            # print(self.predicter_5.dqn.watshi_xxx)
        
        # Even a game with 5 players is relatively short (it takes 3 days time). 
        # Hence, we update the target model every 2 days.
        if day % opt.target_W_update == 0:
            if n_agents == 15:
                self.predicter_15.update_target_dqn()
            elif n_agents == 5:   
                self.predicter_5.update_target_dqn()
            
            self.BLR.E_W_target = self.BLR.E_W
            self.BLR.Cov_W_target = self.BLR.Cov_W
 
def save_npz_5(model, filename):
    lll = dict()
    n_layer = 0
    for i in range(1,4):
        W_np, b_np = model.get_layer('CNN' + str(i)).get_weights()
        lll['arr_' + str(n_layer)] = W_np
        n_layer += 1
        lll['arr_' + str(n_layer)] = b_np
        n_layer += 1
    np.save(filename, lll, allow_pickle=True)
    
def save_npz_15(model, filename):
    lll = dict()

    W1_3d_np, b1_3d_np = model.model3d.get_layer('CNN1').get_weights() 
    lll['arr_0'] = W1_3d_np
    lll['arr_1'] = b1_3d_np
    
    W2_3d_np, b2_3d_np = model.model3d.get_layer('CNN2').get_weights() 
    lll['arr_2'] = W2_3d_np
    lll['arr_3'] = b2_3d_np
    
    W1_2d_np, b1_2d_np = model.model2d.get_layer('CNN1').get_weights() 
    lll['arr_4'] = W1_2d_np
    lll['arr_5'] = b1_2d_np
    
    W2_2d_np, b2_2d_np = model.model2d.get_layer('CNN2').get_weights() 
    lll['arr_6'] = W2_2d_np
    lll['arr_7'] = b2_2d_np
    
    np.save(filename, lll, allow_pickle=True)

# run
if __name__ == '__main__':
    agent = PretrainedSajinPlayer()
    
    models_path = os.path.dirname(__file__) + "/models"
    if not os.path.exists(models_path):
        os.makedirs(models_path)

    print("--- Initiating training for a 15-player setup ! ---")
    n_iter = 0
    for i in range(1,6):
        for j in range(100):
            log_path = os.path.dirname(__file__) + "/log/ANAC2020Log/log15/"  + "{0:03d}".format(i) +  "/game/" + "{0:03d}".format(j) + ".log"
            df, roleMap, is_werewolf_win, n_days, idx = aiwolfpy.read_log(log_path, 15)
                
            agent.myidx = idx
            for d in range(n_days):
                if d == 0:
                    agent.initialize(df, n_agents=15)
                    continue
                            
                agent.update(request='DAILY_INITIALIZE', day=d, roleMap=roleMap, is_werewolf_win=is_werewolf_win, n_agents=15)
                        
                if d != 0:
                    agent.update(request='FINISH', day=d, roleMap=roleMap, is_werewolf_win=is_werewolf_win, n_agents=15)
            
            if n_iter % 20 == 0:                    
                print("Number of Iteration: " + str(n_iter))
                print("--- Saving the " + str(i) + "-" + str(j) + " trained model for a 15-player setup ! ---")
                save_npz_15(agent.predicter_15.dqn, models_path + '/dqn_15_' + str(i) + "_" + str(j))
                print("--- SAVED ---")
                
            n_iter += 1
    
    print("--- Saving the trained model for a 15-player setup ! ---")
    save_npz_15(agent.predicter_15.dqn, models_path + '/dqn_15')
    
    agent = PretrainedSajinPlayer()
    print("--- Initiating training for a 5-player setup ! ---")
    n_iter = 0
    for i in range(1,6):
        for j in range(100):
            log_path = os.path.dirname(__file__) + "/log/ANAC2020Log/log05/"  + "{0:03d}".format(i) +  "/game/" + "{0:03d}".format(j) + ".log"
            df, roleMap, is_werewolf_win, n_days, idx = aiwolfpy.read_log(log_path, 5)
                
            agent.myidx = idx
            for d in range(n_days):
                if d == 0:
                    agent.initialize(df, n_agents=5)
                    continue
                            
                agent.update(request='DAILY_INITIALIZE', day=d, roleMap=roleMap, is_werewolf_win=is_werewolf_win, n_agents=5)
                        
                if d != 0:
                    agent.update(request='FINISH', day=d, roleMap=roleMap, is_werewolf_win=is_werewolf_win, n_agents=5)
            
            if n_iter % 20 == 0:                    
                print(str(i) + "-" + str(j))
                print("Number of Iteration: " + str(n_iter))
                print("--- Saving the " + str(i) + "-" + str(j) + " trained model for a 5-player setup ! ---")
                save_npz_5(agent.predicter_5.dqn.model, models_path + '/dqn_5_' + str(i) + "_" + str(j))
                print("--- SAVED ---")
                
            n_iter += 1
    
    print("--- Saving the trained model for a 5-player setup ! ---")
    save_npz_5(agent.predicter_5.dqn.model, models_path + '/dqn_5')