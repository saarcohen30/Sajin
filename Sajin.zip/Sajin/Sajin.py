#!/usr/bin/env python
from __future__ import print_function, division 


import aiwolfpy
import aiwolfpy.contentbuilder as cb
import logging, json
import os
import sys
import random
from calups import Agent
from cash_keras import PythonPlayer


# PACKAGE_PARENT = '..'
# SCRIPT_DIR = os.path.dirname(os.path.realpath(os.path.join(os.getcwd(), os.path.expanduser(__file__))))
# sys.path.append(os.path.normpath(os.path.join(SCRIPT_DIR, PACKAGE_PARENT)))

import aiwolfpy.cash
from win_counter import WinCounter
# import utils
# from utils import opt
# from blr import BayesianLinearRegression
import numpy as np

# import tensorflow as tf
# from keras import backend as K
# config = tf.compat.v1.ConfigProto(intra_op_parallelism_threads=1, inter_op_parallelism_threads=1, \
#                         allow_soft_placement=True, device_count = {'CPU': 1})
# session = tf.compat.v1.Session(config=config)
# K.set_session(session)

# from keras.optimizers import RMSprop


myname = 'Sajin'

class SajinPlayer(object):
    total_num_days = 0
    def __init__(self, agent_name):
        # myname
        self.myname = agent_name
        
        # predictor from sample
        # DataFrame -> P
        self.predicter_15 = aiwolfpy.cash.StaticPredictor_15()
        self.predicter_5 = aiwolfpy.cash.StaticPredictor_5("/data/dqn_5_1_80.npy")
        self.predicter_5_deep = aiwolfpy.cash.StaticPredictor_5("/data/model_60_0820.npz")
        
        self.CalupsAgent = Agent(myname)
        self.cashKerasAgent = PythonPlayer(myname)
        
        self.win_counter = WinCounter()
        # List of strong agents
        self.strong_agents = []
        # self.replay_buffer = utils.ReplayBuffer(replay_buffer_size=10000)
        # self.optimizer = RMSprop(learning_rate=0.0025, rho=0.95, epsilon=0.01)
        # self.loss = tf.keras.losses.MSE
        # self.loss_metric = tf.keras.metrics.Mean(name="loss")
        # self.q_metric = tf.keras.metrics.Mean(name="Q_value")
        
    def getName(self):
        # logging.debug("# GETNAME")
        return self.myname
        
    def initialize(self, base_info, diff_data, game_setting):
        ### Logging ###
        # logging.debug("# INITIALIZE")
        # logging.debug("Game Setting:")
        # logging.debug(json.dumps(game_setting, indent=2))
        # logging.debug("Base Info:")
        # logging.debug(json.dumps(base_info, indent=2))
        # logging.debug("Diff Data:")
        # logging.debug(diff_data)
        
        #############################################
        
        self.base_info = base_info
        # game_setting
        self.game_setting = game_setting
        
        self.cashKerasAgent.initialize(base_info, diff_data, game_setting)
        
        # initialize
        if self.game_setting['playerNum'] == 15:
            self.predicter_15.initialize(base_info, game_setting)
            self.CalupsAgent.initialize(base_info, diff_data, game_setting)
        elif self.game_setting['playerNum'] == 5:   
            self.predicter_5.initialize(base_info, game_setting)
            self.predicter_5_deep.initialize(base_info, game_setting)
                
        ### EDIT FROM HERE ###     
        self.divined_list = []
        self.comingout = ''
        self.myresult = ''
        self.not_reported = False
        self.vote_declare = 0
        self.vote_15 = np.zeros((15, 15))
        self.vote_5 = np.zeros((5, 5))
        self.strong_agents = self.win_counter.initialize()
        self.reward = 0
        self.is_done = False
        self.executed = -1
        self.attacked = -1
        
        # List of divined werewolves
        self.black_list = []
        # List of divined possessed agents
        self.pos_list = []
        # List of divined villager-aligned players, which include both
        # Mediums and Bodyguards as well
        self.vil_list = []
        
        # List of agents which came out as Seers
        self.seer_list = []
        # List of agents which came out as Mediums
        self.medium_list = []
        # List of agents which came out as Bodyguards
        self.bodyguard_list = []

        
    def update(self, base_info, diff_data, request):
        ### Logging ###
        # logging.debug("# UPDATE")
        # logging.debug("Request:")
        # logging.debug(request)
        # logging.debug("Base Info:")
        # logging.debug(json.dumps(base_info, indent=2))
        # logging.debug("Diff Data:")
        # logging.debug(diff_data)
        #############################################
        
        self.total_num_days += 1
        self.base_info = base_info
        
        # Documenting agents which came out as Seers, Mediums and Bodyguards.
        for i in range(diff_data.shape[0]):
            if "COMINGOUT" in diff_data['text'][i]:
                if "SEER" in diff_data['text'][i] and not int(diff_data['agent'][i]) in self.seer_list:
                    self.seer_list.append(int(diff_data['agent'][i]))
                if "MEDIUM" in diff_data['text'][i] and not int(diff_data['agent'][i]) in self.medium_list:
                    self.medium_list.append(int(diff_data['agent'][i]))
                if "BODYGUARD" in diff_data['text'][i] and not int(diff_data['agent'][i]) in self.bodyguard_list:
                    self.bodyguard_list.append(int(diff_data['agent'][i]))
        
        # result
        if request == 'DAILY_INITIALIZE':
            for i in range(diff_data.shape[0]):
                # print(diff_data['type'][i])

                if diff_data['type'][i] == 'talk':
                    self.not_reported = True
                    self.myresult = diff_data['text'][i]
                # IDENTIFY
                if diff_data['type'][i] == 'identify':
                    self.not_reported = True
                    self.myresult = diff_data['text'][i]

                # DIVINE
                if diff_data['type'][i] == 'divine':
                    self.not_reported = True
                    self.myresult = diff_data['text'][i]

                # GUARD
                if diff_data['type'][i] == 'guard':
                    self.myresult = diff_data['text'][i]

            # POSSESSED
            if self.base_info['myRole'] == 'POSSESSED':
                self.not_reported = True
        
        # UPDATE
        self.cashKerasAgent.update(base_info, diff_data, request)
        if self.game_setting['playerNum'] == 15:
            self.CalupsAgent.update(base_info, diff_data, request)
            # update pred
            self.predicter_15.update(diff_data)
        else:
            self.predicter_5_deep.update(diff_data)
            self.predicter_5.update(diff_data)
            
        # FINISH
        if request == 'FINISH':
            self.is_done = True
            if self.win_counter.is_finish == True:
                return None
            self.win_counter.is_finish = True
            is_werewolf_win = self.win_counter.finish(base_info, diff_data)
            
        # Updating the Seers' black lists
        if base_info['myRole'] == 'SEER':
            # Note that the update is performed solely for Seer agents.
            # Obviously, agents which were divined as Werewolves are 
            # inserted into the black list.
            for i in range(diff_data.shape[0]):
                if diff_data['type'][i] == 'divine':
                    role = diff_data['text'][i].split()[2] 
                    if role == 'WEREWOLF':
                        black_agent = diff_data['text'][i].split()[1]
                        black_agent_idx = int(black_agent.replace('Agent[','').replace(']',''))
                        self.black_list.append(black_agent_idx)
                
                    elif role == 'POSSESSED':
                        pos_agent = diff_data['text'][i].split()[1]
                        pos_agent_idx = int(pos_agent.replace('Agent[','').replace(']',''))
                        self.pos_list.append(pos_agent_idx)
                    
                    elif role == 'VILLAGER' or role == 'MEDIUM' or role == 'BODYGUARD':
                        vil_agent = diff_data['text'][i].split()[1]
                        vil_agent_idx = int(vil_agent.replace('Agent[','').replace(']',''))
                        self.vil_list.append(vil_agent_idx)

        
        
    def dayStart(self):
        ### Logging ###
        # logging.debug("# DAYSTART")
        
        #############################################
         
        self.CalupsAgent.dayStart()
        self.cashKerasAgent.dayStart()
        
        self.vote_declare = 0
        self.talk_turn = 0
        self.whis_declare = 0
        self.reward = 0
        return None
    
    def talk(self):
        ### Logging ###
        # logging.debug("# TALK")

        #############################################
        
        if self.game_setting['playerNum'] == 15:
            
            self.talk_turn += 1
            # rand = random.random()
            # if rand > 2/3:
            #     return self.CalupsAgent.talk()
            # elif rand <= 2/3 and rand > 1/3:
            #     return self.cashKerasAgent.talk()
            
            # 1.comingout anyway
            if self.base_info['myRole'] == 'SEER' and self.comingout == '':
                self.comingout = 'SEER'
                return cb.comingout(self.base_info['agentIdx'], self.comingout)
            elif self.base_info['myRole'] == 'MEDIUM' and self.comingout == '':
                self.comingout = 'MEDIUM'
                return cb.comingout(self.base_info['agentIdx'], self.comingout)
            elif self.base_info['myRole'] == 'POSSESSED' and self.comingout == '':
                self.comingout = 'SEER'
                return cb.comingout(self.base_info['agentIdx'], self.comingout)
            
            # 2.report
            if self.base_info['myRole'] == 'SEER' and self.not_reported:
                self.not_reported = False
                return self.myresult
            elif self.base_info['myRole'] == 'MEDIUM' and self.not_reported:
                self.not_reported = False
                return self.myresult
            elif self.base_info['myRole'] == 'POSSESSED' and self.not_reported:
                self.not_reported = False
                # FAKE DIVINE
                # highest prob ww in alive agents
                p = -1
                idx = 1
                p0_mat = self.predicter_15.ret_pred()
                for i in range(1, 16):
                    p0 = p0_mat[i-1, 1]
                    if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                        p = p0
                        idx = i
                self.myresult = 'DIVINED Agent[' + "{0:02d}".format(idx) + '] ' + 'HUMAN'
                return self.myresult
                
            # 3.declare vote if not yet
            if self.vote_declare != self.vote():
                self.vote_declare = self.vote()
                return cb.vote(self.vote_declare)
                
            # 4. skip
            if self.talk_turn <= 10:
                return cb.skip()
                
            return cb.over()
        else:
            self.talk_turn += 1
            
            rand = random.random()
            # if rand > 2/3:
            #     return self.cashKerasAgent.talk()

            # 1.comingout anyway
            if self.base_info['myRole'] == 'SEER' and self.comingout == '':
                self.comingout = 'SEER'
                return cb.comingout(self.base_info['agentIdx'], self.comingout)
            elif self.base_info['myRole'] == 'MEDIUM' and self.comingout == '':
                self.comingout = 'MEDIUM'
                return cb.comingout(self.base_info['agentIdx'], self.comingout)
            elif self.base_info['myRole'] == 'POSSESSED' and self.comingout == '':
                self.comingout = 'SEER'
                return cb.comingout(self.base_info['agentIdx'], self.comingout)

            # 2.report
            if self.base_info['myRole'] == 'SEER' and self.not_reported:
                self.not_reported = False
                return self.myresult
            elif self.base_info['myRole'] == 'MEDIUM' and self.not_reported:
                self.not_reported = False
                return self.myresult
            elif self.base_info['myRole'] == 'POSSESSED' and self.not_reported:
                self.not_reported = False
                # FAKE DIVINE
                # highest prob ww in alive agents
                p = -1
                idx = 1
                if rand > 1/2:
                    p0_mat = self.predicter_5_deep.ret_pred_wx(r=2)
                else:
                    p0_mat = self.predicter_5.ret_pred_wx(r=2)
                    
                for i in range(1, 6):
                    p0 = p0_mat[i-1, 1]
                    if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                        p = p0
                        idx = i
                self.myresult = 'DIVINED Agent[' + "{0:02d}".format(idx) + '] ' + 'HUMAN'

            # 3.declare vote if not yet
            if self.vote_declare != self.vote():
                self.vote_declare = self.vote()
                return cb.vote(self.vote_declare)

            # 4. skip
            if self.talk_turn <= 10:
                return cb.skip()
                
            return cb.over()
    
    def whisper(self):
        ### Logging ###
        # logging.debug("# WHISPER")
        #############################################
        
        if self.game_setting['playerNum'] == 15:
            rand = random.random()
            if rand > 2/3:
                return self.CalupsAgent.whisper()
            elif rand <= 2/3 and rand > 1/3:
                return self.cashKerasAgent.whisper()
        
        if self.whis_declare == 0:
            self.whis_declare += 1
            return cb.comingout(self.base_info['agentIdx'], 'VILLAGER')
        else:
            return cb.skip()
        
    def vote(self):
        ### Logging ###
        # logging.debug("# VOTE")
        ############################################


        if self.game_setting['playerNum'] == 15:
            # count vote
            rand = random.random()
            if rand > 2/3:
                return self.CalupsAgent.vote()
            elif rand <= 2/3 and rand > 1/3:
                return self.cashKerasAgent.vote()
                
            idx = 1
            self.vote_15 = self.predicter_15.x_3d[:, :, 8]
            for i in range(1, 16):
                if self.base_info['statusMap'][str(i)] == 'DEAD':
                    self.vote_15[i-1, :] = 0
            self.vote_15[self.base_info['agentIdx']-1, :] = 0
            p0_mat = self.predicter_15.ret_pred_wn()
            if self.base_info['myRole'] == "WEREWOLF":
                # idx = utils.vote_werewolf_15(self, p0_mat)
                p = -1
                idx = 1
                for i in range(1, 16):
                    p0 = p0_mat[i-1, 1]
                    if str(i) in self.base_info['roleMap'].keys():
                        p0 *= 0.5
                    if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                        p = p0 * (1.0 + self.vote_15[:, i-1].sum()*1.0)
                        idx = i
            elif self.base_info['myRole'] == "POSSESSED":
                # idx = utils.vote_possessed_15(self, p0_mat)
                p = -1
                idx = 1
                for i in range(1, 16):
                    p0 = p0_mat[i-1, 1]
                    if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                        p = p0 * (1.0 + self.vote_15[:, i-1].sum()*1.0)
                        idx = i
            elif self.base_info['myRole'] == "SEER":
                if len(self.black_list) != 0:
                    # If a Werewolf was successfully divined by a Seer,
                    # he should be voted.
                    idx = 1
                    for i in range(1, 16):
                        if self.base_info['statusMap'][str(i)] == 'ALIVE' and i in self.black_list:
                            idx = i
                            break
                        break
                elif len(self.pos_list) != 0:
                    # If a Possessed agent was successfully divined by a Seer,
                    # he should be voted.
                    idx = 1
                    for i in range(1, 16):
                        if self.base_info['statusMap'][str(i)] == 'ALIVE' and i in self.pos_list:
                            idx = i
                            break
                        break
                else:
                    # idx = utils.vote_seer_5(self, p0_mat)
                    p = -1
                    idx = 1
                    for i in range(1, 16):
                        p0 = p0_mat[i-1, 1]
                        if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p and not (i in self.vil_list):
                            p = p0 * (1.0 + self.vote_15[:, i-1].sum()*0.5)
                            idx = i
            else:
                # idx = utils.vote_human_15(self, p0_mat)
                if self.base_info['day'] < 4:
                    if len(self.seer_list) > 2:
                        p = -1
                        idx = 1
                        for i in self.seer_list:
                            if self.base_info['statusMap'][str(i)] == 'ALIVE' and i != self.base_info['agentIdx']:
                                p0 = p0_mat[i-1, 1]
                                if p0 > p:
                                    p = p0 * (1.0 + self.vote_15[:, i-1].sum()*0.5)
                                    idx = i
                    elif len(self.medium_list) > 2:
                        p = -1
                        idx = 1
                        for i in self.medium_list:
                            if self.base_info['statusMap'][str(i)] == 'ALIVE' and i != self.base_info['agentIdx']:
                                p0 = p0_mat[i-1, 1]
                                if p0 > p:
                                    p = p0 * (1.0 + self.vote_15[:, i-1].sum()*0.5)
                                    idx = i
                    elif len(self.bodyguard_list) > 2:
                        p = -1
                        idx = 1
                        for i in self.bodyguard_list:
                            if self.base_info['statusMap'][str(i)] == 'ALIVE' and i != self.base_info['agentIdx']:
                                p0 = p0_mat[i-1, 1]
                                if p0 > p:
                                    p = p0 * (1.0 + self.vote_15[:, i-1].sum()*0.5)
                                    idx = i
                else:
                    # highest prob ww in alive agents provided watashi ningen
                    p = -1
                    idx = 1
                    for i in range(1, 16):
                        p0 = p0_mat[i-1, 1]
                        if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                            p = p0 * (1.0 + self.vote_15[:, i-1].sum()*0.5)
                            idx = i
            return idx
        else: # 5 players
            rand = random.random()
            # if rand > 2/3:
            #     return self.cashKerasAgent.vote()
            if rand > 1/2:
                self.vote_5 = self.predicter_5_deep.x_3d[:, :, 8]
            else:
                self.vote_5 = self.predicter_5.x_3d[:, :, 8]
            
            idx = 1
            if self.base_info['myRole'] == "WEREWOLF":
                if rand > 1/2:
                    p0_mat = self.predicter_5_deep.ret_pred_wx(r=1)
                else:
                    p0_mat = self.predicter_5.ret_pred_wx(r=1)

                # idx = utils.vote_werewolf_5(self, p0_mat)
                p = -1
                idx = 1
                for i in range(1, 6):
                    p0 = p0_mat[i-1, 3]
                    if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                        p = p0 * (1.0 + self.vote_5[:, i-1].sum()*1.0)
                        idx = i
            elif self.base_info['myRole'] == "POSSESSED":
                if rand > 1/2:
                    p0_mat = self.predicter_5_deep.ret_pred_wx(r=2)
                else:
                    p0_mat = self.predicter_5.ret_pred_wx(r=2)
                    
                # idx = utils.vote_possessed_5(self, p0_mat)
                p = -1
                idx = 1
                for i in range(1, 6):
                    p0 = p0_mat[i-1, 3]
                    if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                        p = p0 * (1.0 + self.vote_5[:, i-1].sum()*1.0)
                        idx = i
            elif self.base_info['myRole'] == "SEER":
                if len(self.black_list) != 0:
                    # If a Werewolf was successfully divined by a Seer,
                    # he should be voted.
                    idx = 1
                    for i in range(1, 6):
                        if self.base_info['statusMap'][str(i)] == 'ALIVE' and i in self.black_list:
                            idx = i
                            break
                        break
                elif len(self.pos_list) != 0:
                    # If a Possessed agent was successfully divined by a Seer,
                    # he should be voted.
                    idx = 1
                    for i in range(1, 6):
                        if self.base_info['statusMap'][str(i)] == 'ALIVE' and i in self.pos_list:
                            idx = i
                            break
                        break
                else:
                    if rand > 1/2:
                        p0_mat = self.predicter_5_deep.ret_pred_wx(r=3)
                    else:
                        p0_mat = self.predicter_5.ret_pred_wx(r=3)

                    # idx = utils.vote_seer_5(self, p0_mat)
                    p = -1
                    idx = 1
                    for i in range(1, 6):
                        p0 = p0_mat[i-1, 1]
                        if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                            p = p0 * (1.0 + self.vote_5[:, i-1].sum()*0.5)
                            idx = i
            else:
                idx = 1
                if rand > 1/2:
                    p0_mat = self.predicter_5_deep.ret_pred_wx(r=0)
                else:
                    p0_mat = self.predicter_5.ret_pred_wx(r=0)

                # If there are two Seers that came out - 
                # the agent shall vote for any agent other than itself.
                if len(self.seer_list) >= 2:
                    p = -1
                    idx = 1
                    for i in range(1, 6):
                        if self.base_info['statusMap'][str(i)] == 'ALIVE' and not (i in self.seer_list) and (i != self.base_info['agentIdx']):
                            p0 = p0_mat[i-1, 1]
                            if p0 > p:
                                p = p0 * (1.0 + self.vote_5[:, i-1].sum()*0.5)
                                idx = i
                        # else:
                        #     continue
                        # break
                else:
                    # idx = utils.vote_human_5(self, p0_mat)
                    p = -1
                    idx = 1
                    for i in range(1, 6):
                        p0 = p0_mat[i-1, 1]
                        if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                            p = p0 * (1.0 + self.vote_5[:, i-1].sum()*0.5)
                            idx = i
            return idx
    
    def attack(self):
        ### Logging ###
        # logging.debug("# ATTACK")
        
        #############################################
        
        if self.game_setting['playerNum'] == 15:
            rand = random.random()
            if rand > 2/3:
                return self.CalupsAgent.attack()
            elif rand <= 2/3 and rand > 1/3:
                return self.cashKerasAgent.attack()
                
            # highest prob hm in alive agents
            p = -1
            idx = 1
            p0_mat = self.predicter_15.ret_pred()
            for i in range(1, 16):
                p0 = p0_mat[i-1, 0]
                if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p and i not in self.base_info['roleMap'].keys():
                    p = p0
                    idx = i
            # return utils.attack_15(self, p0_mat)
            return idx
        else:
            self_id = self.base_info['agentIdx']
            rand = random.random()
            if rand > 2/3:
                return self.cashKerasAgent.attack()
            elif rand <= 2/3 and rand > 1/3:
                p0_mat = self.predicter_5_deep.ret_pred_wx(r=1)
            else:
                p0_mat = self.predicter_5.ret_pred_wx(r=1)
                
            # If there is a single Seer CO, it will be attacked, 
            # and if there are two Seer COs, the agent will attack a strong 
            # villager other than a Seer.
            if self.base_info['day'] == 1 and ((len(self.seer_list) == 1 and int(self.seer_list[0]) == self_id) or len(self.seer_list) > 0) :
                if len(self.seer_list) == 1 and int(self.seer_list[0]) != self_id:
                    return int(self.seer_list[0])
            elif len(self.strong_agents) > 0:
                # Strong villagers shall be attacked
                p = 1
                idx = 1
                for i in self.strong_agents:
                    p0 = p0_mat[int(i)-1, 2]
                    if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 < p and int(i) != self_id:
                        p = p0
                        idx = i
                return idx
                        
            # lowest prob ps in alive agents

            p = 1
            idx = 1
            for i in range(1, 6):
                p0 = p0_mat[i-1, 2]
                if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 < p and i != self_id:
                    p = p0
                    idx = i
            # return utils.attack_5(self, p0_mat)
            return idx
    
    def divine(self):
        ### Logging ###
        # logging.debug("# DIVINE")
        #############################################

        if self.game_setting['playerNum'] == 15:
            rand = random.random()
            if rand > 2/3:
                return self.CalupsAgent.divine()
            elif rand <= 2/3 and rand > 1/3:
                return self.cashKerasAgent.divine()
            
            # highest prob ww in alive and not divined agents provided watashi ningen
            p = -1
            idx = 1
            p0_mat = self.predicter_15.ret_pred_wn()
            # idx = utils.divine_15(self, p0_mat)
            for i in range(1, 16):
                p0 = p0_mat[i-1, 1]
                if self.base_info['statusMap'][str(i)] == 'ALIVE' and i not in self.divined_list and p0 > p:
                    p = p0
                    idx = i
            self.divined_list.append(idx)
            return idx
        else:
            # highest prob ww in alive and not divined agents provided watashi ningen
            p = -1
            idx = 1
            rand = random.random()
            if rand > 2/3:
                return self.cashKerasAgent.divine()
            elif rand <= 2/3 and rand > 1/3:
                p0_mat = self.predicter_5_deep.ret_pred_wx(r=3)
            else:
                p0_mat = self.predicter_5.ret_pred_wx(r=3)
                
            # idx = utils.divine_5(self, p0_mat)
            for i in range(1, 6):
                p0 = p0_mat[i-1, 1]
                if self.base_info['statusMap'][str(i)] == 'ALIVE' and i not in self.divined_list and p0 > p:
                    p = p0
                    idx = i
            self.divined_list.append(idx)
            return idx

    def guard(self):
        ### Logging ###
        # logging.debug("# GUARD")
        #############################################
        
        if self.game_setting['playerNum'] == 15:
            rand = random.random()
            if rand > 2/3:
                return self.CalupsAgent.guard()
            elif rand <= 2/3 and rand > 1/3:
                return self.cashKerasAgent.guard()
            
            # highest prob hm in alive agents
            p = -1
            idx = 1
            p0_mat = self.predicter_15.ret_pred()
            for i in range(1, 16):
                p0 = p0_mat[i-1, 0]
                if self.base_info['statusMap'][str(i)] == 'ALIVE' and p0 > p:
                    p = p0
                    idx = i
            return idx
        else:
            # no need
            return 1
    
    def finish(self):
        # logging.debug("# FINISH")

        self.win_counter.finish_term(100)
        pass
        
 

agent = SajinPlayer(myname)

# run
if __name__ == '__main__':
    aiwolfpy.connect_parse(agent)
    