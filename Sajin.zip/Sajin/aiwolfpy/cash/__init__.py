from __future__ import print_function, division 
# from .predictor_15 import Predictor_15
# from .predictor_5 import Predictor_5
from .predictor_cedec2017 import StaticPredictor_15
from .predictor_cedec2017_5 import StaticPredictor_5
from .predictor_cedec2017_keras import Predictor_15_Keras
from .tensor5460 import Tensor5460
from .tensor60 import Tensor60

