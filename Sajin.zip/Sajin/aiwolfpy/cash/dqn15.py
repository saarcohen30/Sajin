import numpy as np
import os
from .tensor5460 import Tensor5460

import tensorflow as tf
from keras import backend as K
config = tf.compat.v1.ConfigProto(intra_op_parallelism_threads=1, inter_op_parallelism_threads=1, \
                        allow_soft_placement=True, device_count = {'CPU': 1})
session = tf.compat.v1.Session(config=config)
K.set_session(session)
from keras import Model
from keras.models import Sequential
from keras.layers import Dense, Conv1D, Activation
from keras.optimizers import RMSprop
from keras.utils.generic_utils import get_custom_objects
from tensorflow.python.ops.numpy_ops import np_config
np_config.enable_numpy_behavior()

def custom_relu(x):
    return K.minimum(K.maximum(x, 0), 6)

get_custom_objects().update({'custom_relu': Activation(custom_relu)})


class DQNetwork15(Model):
    """
    Class for DQN model architecture.
    """
    
    def __init__(self, t3d_mat, t2d_mat, t2d, watshi_ningen, pretrain=True):
        super(DQNetwork15, self).__init__()
        
        if pretrain:
            lll = np.load(os.path.dirname(__file__)+"/data/model_5460_0819.npz")
            
            W1_3d_np = lll['arr_0']
            W1_3d_np = W1_3d_np.reshape((1,) + W1_3d_np.shape)
            b1_3d_np = lll['arr_1']
    
            W2_3d_np = lll['arr_2']
            W2_3d_np = W2_3d_np.reshape((1,) + W2_3d_np.shape)
            b2_3d_np = lll['arr_3']
    
            W1_2d_np = lll['arr_4']
            W1_2d_np = W1_2d_np.reshape((1,) + W1_2d_np.shape)
            b1_2d_np = lll['arr_5']
    
            W2_2d_np = lll['arr_6']
            W2_2d_np = W2_2d_np.reshape((1,) + W2_2d_np.shape)
            b2_2d_np = lll['arr_7']
        else:
            lll = np.load(os.path.dirname(__file__) + "/data/dqn_15.npy", allow_pickle=True)
            
            W1_3d_np = lll.item().get('arr_0')
            b1_3d_np = lll.item().get('arr_1')
        
            W2_3d_np = lll.item().get('arr_2')
            b2_3d_np = lll.item().get('arr_3')
        
            W1_2d_np = lll.item().get('arr_4')
            b1_2d_np = lll.item().get('arr_5')
            
            W2_2d_np = lll.item().get('arr_6')
            b2_2d_np = lll.item().get('arr_7')


        self.model3d = Sequential()
        self.model3d.add(Conv1D(filters=32, name='CNN1', kernel_size=1, strides=1, use_bias=True, input_shape=(15, 15, 12)))
        self.model3d.add(Activation(custom_relu, name='SpecialReLU1'))
        self.model3d.add(Conv1D(filters=9, name='CNN2', kernel_size=1, strides=1, use_bias=True, input_shape=(15, 15, 32)))
        self.model3d.add(Activation(custom_relu, name='SpecialReLU2'))
        self.model3d.get_layer('CNN1').set_weights([W1_3d_np, b1_3d_np])
        self.model3d.get_layer('CNN2').set_weights([W2_3d_np, b2_3d_np])

        self.model2d = Sequential()
        self.model2d.add(Conv1D(filters=32, name='CNN1', kernel_size=1, strides=1, use_bias=True, input_shape=(15, 8)))
        self.model2d.add(Activation(custom_relu, name='SpecialReLU1'))
        self.model2d.add(Conv1D(filters=3, name='CNN2', kernel_size=1, strides=1, use_bias=True, input_shape=(15, 32)))
        self.model2d.add(Activation(custom_relu, name='SpecialReLU2'))
        self.model2d.get_layer('CNN1').set_weights([W1_2d_np, b1_2d_np])
        self.model2d.get_layer('CNN2').set_weights([W2_2d_np, b2_2d_np])
        
        self.t3d_mat = t3d_mat
        self.t2d_mat = t2d_mat
        self.t2d = t2d
        self.watshi_ningen = watshi_ningen

    @tf.function
    def call(self, input, training=True):
        x3d, x2d = input[0:2]
        wn = False
        if len(input) == 3:
            wn = input[2]
            
        if training and x3d.shape[0] != None:
            z3d = tf.reshape(self.model3d(x3d.reshape((1,) + x3d.shape)), [15*15*3*3,1])
            z2d = tf.reshape(self.model2d(x2d), [15*3,1])   
        else:
            z3d = tf.reshape(self.model3d(x3d), [15*15*3*3,1])
            z2d = tf.reshape(self.model2d(x2d), [15*3,1])   

        u_1 = tf.matmul(self.t3d_mat, z3d) + tf.matmul(self.t2d_mat, z2d)
        
        u_1 -= K.max(u_1)
        if wn:
            p = tf.cast(K.exp(u_1).reshape((5460)) * self.watshi_ningen, tf.float32)
        else:
            p = tf.cast(K.exp(u_1).reshape((5460)), tf.float32)
        return tf.tensordot(self.t2d, p / K.sum(p), axes = [0, 0]).transpose()