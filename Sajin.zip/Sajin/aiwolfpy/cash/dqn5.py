import numpy as np
import os
from .tensor5460 import Tensor5460

import tensorflow as tf
from keras import backend as K
config = tf.compat.v1.ConfigProto(intra_op_parallelism_threads=1, inter_op_parallelism_threads=1, \
                        allow_soft_placement=True, device_count = {'CPU': 1})
session = tf.compat.v1.Session(config=config)
K.set_session(session)
from keras import Model
from keras.models import Sequential
from keras.layers import Dense, Conv1D, Activation
from keras.optimizers import RMSprop
from keras.utils.generic_utils import get_custom_objects
from tensorflow.python.ops.numpy_ops import np_config
np_config.enable_numpy_behavior()

def custom_relu(x):
    return K.minimum(K.maximum(x, 0), 6)

get_custom_objects().update({'custom_relu': Activation(custom_relu)})


class DQNetwork5(Model):
    """
    Class for DQN model architecture.
    """
    
    def __init__(self, t2d, watshi_xxx, pretrain=True):
        super(DQNetwork5, self).__init__()
        
        if pretrain:
            lll = np.load(os.path.dirname(__file__)+"/data/model_60_0820.npz")
    
            W1_np = lll['arr_0']
            W1_np = W1_np.reshape((1,) + W1_np.shape)
            b1_np = lll['arr_1']
        
            W2_np = lll['arr_2']
            W2_np = W2_np.reshape((1,) + W2_np.shape)
            b2_np = lll['arr_3']
        
            W3_np = lll['arr_4']
            W3_np = W3_np.reshape((1,) + W3_np.shape)
            b3_np = lll['arr_5']
        else:
            lll = np.load(os.path.dirname(__file__) + "/data/dqn_5.npy", allow_pickle=True)
            
            W1_np = lll.item().get('arr_0')
            b1_np = lll.item().get('arr_1')
        
            W2_np = lll.item().get('arr_2')
            b2_np = lll.item().get('arr_3')
        
            W3_np = lll.item().get('arr_4')
            b3_np = lll.item().get('arr_5')
            

        self.model = Sequential()
        self.model.add(Conv1D(filters=512, name='CNN1', kernel_size=1, strides=1, use_bias=True, input_shape=(1, 340)))
        self.model.add(Activation(custom_relu, name='SpecialReLU1'))
        self.model.add(Conv1D(filters=256, name='CNN2', kernel_size=1, strides=1, use_bias=True, input_shape=(1, 512)))
        self.model.add(Activation(custom_relu, name='SpecialReLU2'))
        self.model.add(Conv1D(filters=60, name='CNN3', kernel_size=1, strides=1, use_bias=True, input_shape=(1, 256)))


        self.model.get_layer('CNN1').set_weights([W1_np, b1_np])
        self.model.get_layer('CNN2').set_weights([W2_np, b2_np])
        self.model.get_layer('CNN3').set_weights([W3_np, b3_np])

        self.t2d = t2d
        self.watshi_xxx = watshi_xxx
        self.r = 0

    @tf.function
    def call(self, input, training=False):      
        x = input.reshape(1,1,340)
        z3d = self.model(x)
        z3d -= K.max(z3d)
        p = tf.cast(K.exp(z3d).reshape((60)) * self.watshi_xxx[:, self.r], tf.float32)
        return tf.tensordot(self.t2d, p / K.sum(p), axes = [0, 0]).transpose()


