import csv
import pandas as pd

finalists = dict(
                takeda=1,
                otsuki=2,
                HALU=3,
                J0hnDoe=4,
                cube=5,
                daisyo=6,
                Tomo=7,
                simipu=8,
                Udon=9,
                Tomato=10,
                wasabi=11,
                FoxuFoxu=12,
                PaSeRi=13,
                Camellia=14,
                Sashimi=15
                )

def read_log(log_path, n_agents):
    with open(log_path, newline='') as csvfile:
        log_reader = csv.reader(csvfile, delimiter=',')
        agent_ = []
        day_ = []
        type_ = []
        idx_ = []
        turn_ = []
        text_ = []
        roleMap = dict()
        
        day_vote_keys = dict()
        day_attack_vote_keys = dict()
        
        # for medium result
        medium = 0
        is_werewolf_win = False
        agent_idx = 15
        for row in log_reader:
            if row[1] == "status" and int(row[0]) == 0:
                agent_.append(int(row[2])), 
                day_.append(int(row[0])), 
                type_.append('initialize'), 
                idx_.append(int(row[2])), 
                turn_.append(0), 
                text_.append('COMINGOUT Agent[' + "{0:02d}".format(int(row[2])) + '] ' + row[3])
                # medium
                if row[3] == "MEDIUM":
                    medium = row[2]
                    
                if finalists.get(row[5]) < agent_idx:
                    agent_idx = int(row[2])
            elif row[1] == "status":
                agent_.append(int(row[2])), 
                day_.append(int(row[0])), 
                type_.append('status'), 
                idx_.append(int(row[2])), 
                turn_.append(0), 
                text_.append(row[4])
                if row[4] == 'DEAD':
                    roleMap[int(row[0])] = int(row[2])
            elif row[1] == "talk":
                agent_.append(int(row[4])), 
                day_.append(int(row[0])), 
                type_.append('talk'), 
                idx_.append(int(row[2])), 
                turn_.append(int(row[3])), 
                text_.append(row[5])
            elif row[1] == "whisper":
                agent_.append(int(row[4])), 
                day_.append(int(row[0])), 
                type_.append('whisper'), 
                idx_.append(int(row[2])), 
                turn_.append(int(row[3])), 
                text_.append(row[5])
            elif row[1] == "vote":
                agent_.append(int(row[3])), 
                day_.append(int(row[0])), 
                type_.append('vote'), 
                idx_.append(int(row[2])), 
                turn_.append(0), 
                text_.append('VOTE Agent[' + "{0:02d}".format(int(row[3])) + ']')
                
            elif row[1] == "attackVote":
                agent_.append(int(row[3])), 
                day_.append(int(row[0])), 
                type_.append('attack_vote'), 
                idx_.append(int(row[2])), 
                turn_.append(0), 
                text_.append('ATTACK Agent[' + "{0:02d}".format(int(row[3])) + ']')
            elif row[1] == "divine":
                agent_.append(int(row[3])), 
                day_.append(int(row[0])), 
                type_.append('divine'), 
                idx_.append(int(row[2])), 
                turn_.append(0), 
                text_.append('DIVINED Agent[' + "{0:02d}".format(int(row[3])) + '] ' + row[4])
            elif row[1] == "execute":
                # for all
                agent_.append(int(row[2])), 
                day_.append(int(row[0])), 
                type_.append('execute'), 
                idx_.append(0), 
                turn_.append(0), 
                text_.append('Over')
                # for medium
                res = 'HUMAN'
                if row[3] == 'WEREWOLF':
                    res = 'WEREWOLF'
                agent_.append(int(row[2])), 
                day_.append(int(row[0])), 
                type_.append('identify'), 
                idx_.append(medium), 
                turn_.append(0), 
                text_.append('IDENTIFIED Agent[' + "{0:02d}".format(int(row[2])) + '] ' + res)
            elif row[1] == "guard":
                agent_.append(int(row[3])), 
                day_.append(int(row[0])), 
                type_.append('guard'), 
                idx_.append(int(row[2])), 
                turn_.append(0), 
                text_.append('GUARDED Agent[' + "{0:02d}".format(int(row[3])) + ']')
            elif row[1] == "attack":
                agent_.append(int(row[2])), 
                day_.append(int(row[0])), 
                type_.append('attack'), 
                idx_.append(0), 
                turn_.append(0), 
                text_.append('ATTACK Agent[' + "{0:02d}".format(int(row[2])) + ']')
                if row[3] == 'true':
                    # dead
                    agent_.append(int(row[2])), 
                    day_.append(int(row[0])), 
                    type_.append('dead'), 
                    idx_.append(0), 
                    turn_.append(0), 
                    text_.append('Over')
            elif row[1] == "result":
                if row[4] == "WEREWOLF":
                    is_werewolf_win = True
                n_days = row[0]
            else:
                pass


    return pd.DataFrame({"day":day_, "type":type_, "idx":idx_, "turn":turn_, "agent":agent_, "text":text_}), roleMap, is_werewolf_win, int(n_days), agent_idx
    